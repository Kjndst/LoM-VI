-- LoM-VI runtime bootstrap factory.
-- This file does not assume an install path or module namespace.
-- Caller supplies: LOMModLoader, generated ID override table, safe literal table.

return function(Loader, IdData, SafeLiterals, Options)
    assert(type(Loader) == "table" and type(Loader.AfterLoad) == "function", "LOMModLoader.AfterLoad is required")
    IdData = IdData or {}
    SafeLiterals = SafeLiterals or {}
    Options = Options or {}

    local aggregate = IdData.aggregateOverrides or {}
    local split = IdData.splitOverrides or {}
    local report = type(Options.report) == "function" and Options.report or function() end
    local marker = tostring(Options.version or "lom-vi-test")
    local dataPriority = tonumber(Options.dataPriority) or 1100000
    local runtimePriority = tonumber(Options.runtimePriority) or 1100000
    local generatedPriority = tonumber(Options.generatedPriority) or 900000
    local unresolvedSeen = {}

    local function hasCjk(value)
        return type(value) == "string" and value:find("[\228-\233][\128-\191][\128-\191]") ~= nil
    end

    local function getSymbol(value, environment, name)
        if type(value) == "table" then
            if value[name] ~= nil then return value[name] end
            if value.data ~= nil and name == "data" then return value.data end
        end
        if type(environment) == "table" and environment[name] ~= nil then
            return environment[name]
        end
        return nil
    end

    local function lookup(index, tag)
        if tag ~= nil then
            local values = split[tostring(tag)]
            if type(values) ~= "table" then return nil end
            return values[index] or values[tonumber(index)] or values[tostring(index)]
        end
        return aggregate[index] or aggregate[tonumber(index)] or aggregate[tostring(index)]
    end

    local function repairString(value, context)
        if type(value) ~= "string" then return value end
        local replacement = SafeLiterals[value]
        if replacement ~= nil then return replacement end
        if hasCjk(value) then
            local key = tostring(context or "") .. "\0" .. value
            if not unresolvedSeen[key] then
                unresolvedSeen[key] = true
                report("unresolved CJK\t" .. tostring(context or "") .. "\t" .. value:gsub("\n", "\\n"))
            end
        end
        return value
    end

    local function repairValue(value, context, depth, seen)
        local kind = type(value)
        if kind == "string" then return repairString(value, context) end
        if kind ~= "table" or depth >= 4 then return value end
        seen = seen or {}
        if seen[value] then return value end
        seen[value] = true
        for key, child in pairs(value) do
            value[key] = repairValue(child, tostring(context or "") .. "." .. tostring(key), depth + 1, seen)
        end
        return value
    end

    local function applyMap(values, symbolName)
        return function(value, environment)
            local module = type(value) == "table" and value or getSymbol(value, environment, symbolName)
            if type(module) ~= "table" then return value end
            local data = type(module.data) == "table" and module.data or module
            for key, replacement in pairs(values) do data[key] = replacement end
            return value
        end
    end

    local applyAggregate = applyMap(aggregate, "StringDB_CN_Data")
    Loader.AfterLoad("Data.Excel.LanguageData.StringDB_CN_Data", applyAggregate, dataPriority, "lom-vi.aggregate-cn")
    Loader.AfterLoad("Data.Excel.LanguageData.StringDB_EN_Data", applyAggregate, dataPriority, "lom-vi.aggregate-en")

    -- Apply selected Vietnamese IDs directly to split StringDB modules as well.
    -- This avoids competing for Loader.Overlays with an existing English patch.
    for tag, values in pairs(split) do
        if type(tag) == "string" and type(values) == "table" then
            local cnName = "Data.Excel.LanguageData.StringDB_CN_Data_" .. tag
            local enName = "Data.Excel.LanguageData.StringDB_EN_Data_" .. tag
            Loader.AfterLoad(cnName, applyMap(values, "StringDB_CN_Data_" .. tag), dataPriority, "lom-vi.split-cn." .. tag)
            Loader.AfterLoad(enName, applyMap(values, "StringDB_EN_Data_" .. tag), dataPriority, "lom-vi.split-en." .. tag)
        end
    end

    Loader.AfterLoad("Framework.Utils.LuaCommon.Managers.TableDataManager", function(value, environment)
        local manager = getSymbol(value, environment, "TableDataManager") or value
        if type(manager) ~= "table" then return value end
        local flag = "__lomViRuntime_" .. marker
        if manager[flag] then return value end
        manager[flag] = true

        local originalGetLangStr = manager.GetLangStr
        local originalGetLangStrSplit = manager.GetLangStrSplit
        local originalGetRow = manager.GetRow
        local originalGetAttr = manager.GetAttr

        if type(originalGetLangStr) == "function" then
            function manager:GetLangStr(index)
                local replacement = lookup(index, nil)
                if replacement ~= nil then return replacement end
                local ok, result = pcall(originalGetLangStr, self, index)
                if ok and result ~= nil then return repairString(result, "GetLangStr:" .. tostring(index)) end
                if type(index) == "string" then return repairString(index, "GetLangStr:key") end
                return nil
            end
        end

        if type(originalGetLangStrSplit) == "function" then
            function manager:GetLangStrSplit(index, tag)
                local replacement = lookup(index, tag)
                if replacement ~= nil then return replacement end
                local ok, result = pcall(originalGetLangStrSplit, self, index, tag)
                if ok and result ~= nil then
                    return repairString(result, "GetLangStrSplit:" .. tostring(tag) .. ":" .. tostring(index))
                end
                if type(index) == "string" then return repairString(index, "GetLangStrSplit:key") end
                return nil
            end
        end

        if type(originalGetRow) == "function" then
            function manager:GetRow(tableName, rowKey, priority)
                local prefix = "LanguageData.StringDB_CN_Data"
                if type(tableName) == "string" then
                    local pos = tableName:find(prefix, 1, true)
                    if pos then
                        local suffix = tableName:sub(pos + #prefix)
                        local tag = suffix:sub(1,1) == "_" and suffix:sub(2) or nil
                        if tag == "" then tag = nil end
                        local replacement = lookup(rowKey, tag)
                        if replacement ~= nil then return replacement end
                    end
                end
                local result = originalGetRow(self, tableName, rowKey, priority)
                return repairValue(result, tostring(tableName) .. ":" .. tostring(rowKey), 0, {})
            end
        end

        if type(originalGetAttr) == "function" then
            function manager:GetAttr(tableName, attrKey)
                local result = originalGetAttr(self, tableName, attrKey)
                return repairValue(result, tostring(tableName) .. ":" .. tostring(attrKey), 0, {})
            end
        end

        report("LoM-VI localization manager hooks installed")
        return value
    end, runtimePriority, "lom-vi.localization")

    local function wrapGeneratedRows(tableData, source)
        if type(tableData) ~= "table" then return 0 end
        local flag = "__lomViRows_" .. marker
        if tableData[flag] then return 0 end
        local wrapped = 0
        for name, member in pairs(tableData) do
            if type(name) == "string" and type(member) == "function" and name:match("^Get.+Row$") then
                local original = member
                tableData[name] = function(...)
                    local row = original(...)
                    return repairValue(row, tostring(source) .. "." .. name, 0, {})
                end
                wrapped = wrapped + 1
            end
        end
        tableData[flag] = true
        if wrapped > 0 then report("LoM-VI generated-row hooks=" .. tostring(wrapped) .. " source=" .. tostring(source)) end
        return wrapped
    end

    Loader.AfterLoad("Data.Excel.TableData", function(value, environment)
        local tableData = getSymbol(value, environment, "TableData") or value
        wrapGeneratedRows(tableData, "Data.Excel.TableData")
        return value
    end, runtimePriority, "lom-vi.generated-rows")

    Loader.AfterLoad("Gameplay.LogicSystem.SkillCustomizer.SkillCustomSystem", function(value, environment)
        local system = getSymbol(value, environment, "SkillCustomSystem") or value
        if type(system) ~= "table" then return value end
        local flag = "__lomViGeneratedSkill_" .. marker
        if system[flag] then return value end
        for _, methodName in ipairs({"GenerateSkillDescNoRichText", "GenerateSkillBriefDesc", "GenerateSkillDecoText"}) do
            local original = system[methodName]
            if type(original) == "function" then
                system[methodName] = function(self, ...)
                    local results = { original(self, ...) }
                    if type(results[1]) == "string" then
                        results[1] = repairString(results[1], "SkillCustomSystem." .. methodName)
                    end
                    return unpack(results)
                end
            end
        end
        system[flag] = true
        report("LoM-VI generated skill hooks installed")
        return value
    end, generatedPriority, "lom-vi.generated-skill")

    return {
        lookup = lookup,
        repairString = repairString,
        repairValue = repairValue,
        unresolved = unresolvedSeen,
    }
end
