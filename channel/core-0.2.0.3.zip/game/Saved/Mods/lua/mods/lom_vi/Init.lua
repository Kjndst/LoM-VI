-- LoM-VI Core 0.2.0.2 runtime entrypoint.
-- Requires the existing LOMModLoader bootstrap.
local Loader = assert(LOMModLoader, "LOMModLoader is required for LoM-VI")
local Factory = require("mods.lom_vi.BootstrapFactory")
local IdData = require("mods.lom_vi.IdOverrides")
local SafeLiterals = require("mods.lom_vi.SafeLiterals")

local function report(message)
    local logger = Log or LaunchLog
    if logger and logger.Info then
        logger.Info("[LoM-VI] " .. tostring(message))
    elseif logger and logger.Error then
        logger.Error("[LoM-VI] " .. tostring(message))
    end
end

return Factory(Loader, IdData, SafeLiterals, {
    version = "v0.2.0.2",
    -- Static ID overrides should run after English/static overlays.
    dataPriority = 1100000,
    runtimePriority = 1100000,
    -- If CPDD runtime fixes coexist and this module is loaded first,
    -- generated Vietnamese repair runs before its 1000000 wrapper.
    generatedPriority = 900000,
    report = report,
})
